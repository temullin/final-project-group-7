Contacts Between Police and the Public, 2015  NCJ 251145		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Contacts Between Police and the Public, 2015,  NCJ 251145.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6406		
		
This report is one in a series.  More recent editions may be available.		
To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=18		
		
Filename		Table title
cpp15t01.csv		Table 1. Number and percent of U.S. residents age 16 or older with any police contact, by type of contact and demographic characteristics, 2015
cpp15t02.csv		Table 2. Number and percent of U.S. residents age 16 or older with police contact, by type of contact, household income, and city population size, 2015
cpp15t03.csv		Table 3. Number and percent of U.S. residents age 16 or older with police-initiated contact, by type of contact and demographic characteristics, 2015
cpp15t04.csv		Table 4. Number and percent of residents age 16 or older who initiated contact with police, by type of contact and demographic characteristics, 2015
cpp15t05.csv		Table 5. U.S. residents age 16 or older with police contact, by reason for contact, 2011 and 2015
cpp15t06.csv		Table 6. U.S. residents age 16 or older with any police contact, by demographic characteristics, 2011 and 2015
cpp15t07.csv		Table 7. Frequency of police contact during prior 12 months for U.S. residents age 16 or older, by type of contact and race/Hispanic origin, 2015
cpp15t08.csv		Table 8. Percent of contact initiated by police and residents age 16 or older, by type of most recent contact and demographic characteristics, 2015
cpp15t09.csv		Table 9. Demographic characteristics of U.S. residents age 16 or older for whom the most recent contact was police-initiated, by type of contact, 2015
cpp15t10.csv		Table 10. Drivers� perceptions of legitimacy of traffic stops and police behavior, by reason given for stop and police behavior, 2015
cpp15t11.csv		Table 11. Drivers� perception of traffic-stop legitimacy, by reason given and resident demographic characteristics, 2015
cpp15t12.csv		Table 12. Outcomes of traffic stops, by driver demographic characteristics, 2015
cpp15t13.csv		Table 13. Outcomes of traffic stops, by reason for stop, 2015
cpp15t14.csv		Table 14. Drivers� perception that police behaved properly during traffic stops, by outcome of stop and driver demographic characteristics, 2015
cpp15t15.csv		Table 15. Residents� perception of street-stop legitimacy and if police behaved properly during a street stop, by resident demographic characteristics, 2015
cpp15t16.csv		Table 16. Reasons police gave for street stops, by residents� perception of legitimacy and if and police behaved properly, 2015
cpp15t17.csv		Table 17. Residents� perceptions of whether police behaved properly, by outcomes of street stops, 2015
cpp15t18.csv		Table 18. Residents who experienced nonfatal threats or use of force during contacts with police, by demographic characteristics and whether the action was perceived to be necessary or excessive, 2015
cpp15t19.csv		Table 19. Percent of residents who experienced nonfatal threats or use of force during their most recent police-initiated contact or traffic accident, by type of action and whether the force was perceived to be necessary or excessive, 2015
cpp15t20.csv		Table 20. Percent of residents who initiated their most recent contact with police, 2015
cpp15t21.csv		Table 21. Residents� perception of police response and behavior during contacts to request assistance, by demographic characteristics, 2015
		
Figures		
cpp15f01.csv		Figure 1. Percent of U.S. population age 16 or older who had any police contact, by type of contact and reason, 2015
cpp15f02.csv		Figure 2. Percent of U.S. population age 16 or older who had any police contact, by type of most recent contact and reason, 2015
		
Appendix tables		
cpp15at01.csv		Appendix table 1. Estimates and standard errors for figure 1: Percent of U.S. population age 16 or older who had any police contact, by type of contact and reason, 2015
cpp15at02.csv		Appendix table 2. Standard errors for table 1: Number and percent of U.S. residents age 16 or older with any police contact, by type of contact and demographic characteristics, 2015
cpp15at03.csv		Appendix table 3. Standard errors for table 2: Number and percent of U.S. residents age 16 or older with police contact, by type of contact, household income, and city population size, 2015
cpp15at04.csv		Appendix table 4. Standard errors for table 3: Number and percent of U.S. residents age 16 or older with police-initiated contact, by type of contact and demographic characteristics, 2015
cpp15at05.csv		Appendix table 5. Standard errors for table 4: Number and percent of residents age 16 or older who initiated contact with police, by type of contact and demographic characteristics, 2015
cpp15at06.csv		Appendix table 6. Standard errors for table 5: U.S. residents age 16 or older with police contact, by reason for contact, 2011 and 2015
cpp15at07.csv		Appendix table 7. Standard errors for table 6: U.S. residents age 16 or older with any police contact, by demographic characteristics, 2011 and 2015
cpp15at08.csv		Appendix table 8. Standard errors for table 7: Frequency of police contact during prior 12 months for U.S. residents age 16 or older, by type of contact and race/Hispanic origin, 2015
cpp15at09.csv		Appendix table 9. Standard errors for figure 2: Percent of U.S. population age 16 or older who had any police contact, by type of most recent contact and reason, 2015 
cpp15at10.csv		Appendix table 10. Standard errors for table 8: Percent of contact initiated by police and residents age 16 or older, by type of most recent contact and demographic characteristics, 2015
cpp15at11.csv		Appendix table 11. Standard errors for table 9: Demographic characteristics of U.S. residents age 16 or older for whom the most recent contact was police-initiated, by type of contact, 2015
cpp15at12.csv		Appendix table 12. Standard errors for table 10: Drivers� perceptions of legitimacy of traffic stops and police behavior, by reason given for stop and police behavior, 2015
cpp15at13.csv		Appendix table 13. Standard errors for table 11: Drivers� perception of traffic-stop legitimacy, by reason given and resident demographic characteristics, 2015
cpp15at14.csv		Appendix table 14. Standard errors for table 12: Outcomes of traffic stops, by driver demographic characteristics, 2015
cpp15at15.csv		Appendix table 15. Standard errors for table 13: Outcomes of traffic stops, by reason for stop, 2015
cpp15at16.csv		Appendix table 16. Standard errors for table 14: Drivers� perception that police behaved properly during traffic stops, by outcome of stop and driver demographic characteristics, 2015
cpp15at17.csv		Appendix table 17. Standard errors for table 15:  Residents� perception of street-stop legitimacy and if police behaved properly during a street stop, by resident demographic characteristics, 2015
cpp15at18.csv		Appendix table 18. Standard errors for table 16: Reasons police gave for street stops, by residents� perception of legitimacy and if police behaved properly, 2015
cpp15at19.csv		Appendix table 19. Standard errors for table 17: Outcomes of street stops by perception that police behaved properly, 2015
cpp15at20.csv		Appendix table 20. Standard errors for table 18: Residents who experienced nonfatal threats or use of force during contacts with police, by demographic characteristics and whether the action was perceived to be necessary or excessive, 2015
cpp15at21.csv		Appendix table 21. Standard errors for table 19: Percent of residents who experienced nonfatal threats or use of force during their most recent police-initiated contact or traffic accident, by type of action and whether the force was perceived to be necessary or excessive, 2015
cpp15at22.csv		Appendix table 22. Standard errors for table 20: Percent of residents who initiated their most recent contact with police, 2015
cpp15at23.csv		Appendix table 23. Estimates and standard errors for table 21: Residents� perception of police response and behavior during contacts to request assistance, by demographic characteristics, 2015
